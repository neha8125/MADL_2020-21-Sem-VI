package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    EditText editTextNumber1,editTextNumber2;
    Button button1,button2,button3,button4;
    TextView textView1,textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        editTextNumber1=findViewById(R.id.editTextNumber1);
        editTextNumber2=findViewById(R.id.editTextNumber2);
        textView1=findViewById(R.id.textView1);
        textView2=findViewById(R.id.textView2);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        int num1,num2,c;
        int id=v.getId();
        switch(id)
        {
            case R.id.button1:
                num1=Integer.parseInt(editTextNumber1.getText().toString());
                num2=Integer.parseInt(editTextNumber2.getText().toString());
                c=num1+num2;
                Toast.makeText(getApplicationContext(),"Addition is  "+c,Toast.LENGTH_LONG).show();
                break;

            case R.id.button2:
                num1=Integer.parseInt(editTextNumber1.getText().toString());
                num2=Integer.parseInt(editTextNumber2.getText().toString());
                c=num1-num2;
                Toast.makeText(getApplicationContext(),"Subtraction is "+c,Toast.LENGTH_LONG).show();
                break;

            case R.id.button3:
                num1=Integer.parseInt(editTextNumber1.getText().toString());
                num2=Integer.parseInt(editTextNumber2.getText().toString());
                c=num1*num2;
                Toast.makeText(getApplicationContext(),"Multiplication is "+c,Toast.LENGTH_LONG).show();
                break;

            case R.id.button4:
                num1=Integer.parseInt(editTextNumber1.getText().toString());
                num2=Integer.parseInt(editTextNumber2.getText().toString());
                c=num1/num2;
                Toast.makeText(getApplicationContext(),"Division is "+c,Toast.LENGTH_LONG).show();
                break;

        }

    }
}