package com.exp3.tenyears;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity<fac1> extends AppCompatActivity {
    String role[]={"Faculty","Student","Lab Assistant"};
    Spinner spinner;
    ArrayAdapter<String> arrayAdapter;

    EditText editText1,editText2;
    Button button1,button2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner=findViewById(R.id.spinner1);
        arrayAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_item, role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),"Selected Role "+role[position],Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"Nothing is selected",Toast.LENGTH_LONG).show();
            }
        });

        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text1,text2,text3;
                text1=editText1.getText().toString();
                text2=editText2.getText().toString();
                text3=spinner.getSelectedItem().toString();

                if(text1.contentEquals("faculty") && text2.contentEquals("faculty123") && text3.contentEquals("Faculty"))
                {
                    Intent i=new Intent(MainActivity.this, Faculty.class);
                    startActivity(i);
                }
                if(text1.contentEquals("student") && text2.contentEquals("student123") && text3.contentEquals("Student"))
                {
                    Intent i=new Intent(MainActivity.this, Student.class);
                    startActivity(i);
                }
                if(text1.contentEquals("labassis") && text2.contentEquals("labassis123") && text3.contentEquals("Lab Assistant"))
                {
                    Intent i=new Intent(MainActivity.this, LabAssistant.class);
                    startActivity(i);
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(null);
                editText2.setText(null);
            }
        });

    }
}